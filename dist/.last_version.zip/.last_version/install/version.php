<?
$arModuleVersion = array(
	"VERSION" => "1.1.1",
	"VERSION_DATE" => "2024-12-08 15:18:00"
);
?>