drop table if exists awz_autounp_role;
drop table if exists awz_autounp_role_relation;
drop table if exists awz_autounp_permission;