<?
$arModuleVersion = array(
	"VERSION" => "1.1.4",
	"VERSION_DATE" => "2025-07-12 13:26:00"
);
?>