<?
$arModuleVersion = array(
	"VERSION" => "1.1.2",
	"VERSION_DATE" => "2025-05-27 12:28:00"
);
?>