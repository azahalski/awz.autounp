<?php
namespace Awz\Autounp\Access\Custom;

class Helper
{
    public const ADMIN_DECLINE = 1;
}