<?php
namespace Awz\Autounp\Access\Custom;

use Awz\Autounp\Access\Permission;

class RoleDictionary extends Permission\RoleDictionary
{
}