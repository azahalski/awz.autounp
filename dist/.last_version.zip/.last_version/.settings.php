<?php
return array(
    'controllers' => array(
        'value' => array(
            'namespaces' => array(
                '\\Awz\\AutoUnp\\Api\\Controller' => 'api'
            )
        ),
        'readonly' => true
    )
);