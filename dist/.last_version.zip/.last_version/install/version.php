<?
$arModuleVersion = array(
	"VERSION" => "1.0.1",
	"VERSION_DATE" => "2024-11-03 12:37:00"
);
?>